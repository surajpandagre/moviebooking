sampleApp.controller('cancellationController', function($scope,$http, $rootScope, $location) {

$scope.cancelmsg="Cancel your ticket here";
$scope.msg="";
$scope.shows=true;
$scope.email=$rootScope.email;

var refresh = function () {
         $http.get('/booking/getBooking/'+$scope.email).success(function (response) {
			
            $scope.cancelList = response;
            $scope.cancel = "";
        });
	};

    refresh();
	
	$scope.cancelTickets = function (cancel) {
		
           var r = confirm("Are you sure you want to cancel this movie?");
        if (r == true) {
        $http.delete('/booking/deleteBooking/' + cancel._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresh();
			$scope.msg="Ticket cancelled successfully";
        });
      }
    };

});

