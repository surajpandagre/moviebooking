
sampleApp.controller('ConfirmController', function($scope,$http, $rootScope, $location) {

$scope.confirm="Confirm your Tickets";
$scope.totalSeats=$rootScope.totalSeats; 
$scope.totalPrice=$rootScope.totalPrice; 
$scope.showtime=$rootScope.showtime; 
$scope.fromdate=$rootScope.fromdate; 
$scope.todate=$rootScope.todate; 

$scope.shows = true;
$scope.details = false;  


var a = moment($scope.todate);
var b = moment($scope.fromdate);
var c=a.diff(b, 'days') // 1


             var rdts=[];
			
			 for(var i=0;i<=c;i++)
			 {
				 var temp={};
				 var rdt = moment($scope.fromdate).add('days', i);
                 rdt = rdt.format('MM/DD/YYYY');
				 temp.fdate=rdt;
				 rdts.push(temp);
			 }
			
			 $scope.fdts=rdts;


    $scope.changePrice = function () {
		 
		var total=$scope.quantity*$rootScope.totalPrice;
        $scope.totalPrice=total;
    };
	
	$scope.getDate = function (fdts) {
      $rootScope.sdate=fdts.fdate;
    }
	
	$scope.bookTicket = function () {
		 $scope.shows = false;
	     $scope.details = true;
		 
		
		 
		 if($rootScope.sdate==undefined)
		 {
		
			 $scope.sdt=$scope.fromdate;
		 }
		 else{
			 $scope.sdt=$rootScope.sdate;
		 }
		 
		 var bookingid=Math.floor((Math.random() * 1000000) + 1);
         $scope.msg=$scope.name+" your Ticket has been booked Successfully on "+$scope.sdt+" at "+$scope.showtime+". Your Booking Id is: "+bookingid;
    };

});