sampleApp.controller('logoutController',
  ['$scope', '$location','$rootScope', 'AuthService',
  function ($scope, $location,$rootScope, AuthService) {

    $scope.logout = function () {

      // call logout from service
      AuthService.logout()
        .then(function () {
			$rootScope.unm='';
          $location.path('/login');
        });

    };

}]);