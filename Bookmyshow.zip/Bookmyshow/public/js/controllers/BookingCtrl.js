angular.module('BookingCtrl', []).controller('BookingController', function($scope,$http) {

	$scope.tagline = 'Book your movies here!';

});