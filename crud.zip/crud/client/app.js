'use strict';

var app = angular.module('movieApp', [ 'ngRoute' ]);

app.config(function($routeProvider) {

  $routeProvider.when('/', {
    templateUrl: 'views/home.html',
    controller: 'HomeController',
  })
  .when('/movie', {
    templateUrl: 'views/movie.html',
    controller: 'MovieController',
  })
 

});

