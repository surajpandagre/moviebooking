app.controller('MovieController', function($scope, $http){

  var refresh = function () {
        $http.get('/movie/getMovie').success(function (response) {
            console.log('READ IS SUCCESSFUL');
			 $scope.shows = true;
			 $scope.details = false;
            $scope.moviList = response;
            $scope.movi = "";
        });
    };

    refresh();
	
	$scope.setData=function(){
		     $scope.shows = true;
			 $scope.details = false;
			 $scope.searchdiv = false;
	};
	
	     $scope.getMovieDetails = function (movie) {
         $http.get('/movie/getMovie/' + movie._id).success(function (response) {
			 $scope.shows = false;
			 $scope.details = true;
			 $scope.searchdiv = false;
            $scope.movieList = response[0];
			
        });
    };
	
	$scope.searchMovie = function (movie) {
	
         $http.get('/movie/searchMovie/' + movie).success(function (response) {
			 console.log(response);
			 $scope.shows = false;
			 $scope.searchdiv = true;
            $scope.searchdata = response[0];
			
        });
    };

   
});