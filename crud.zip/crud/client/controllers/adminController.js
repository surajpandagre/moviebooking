'use strict';

var app = angular.module('adminApp', [ 'ngRoute' ]);

app.controller('AdminController', function($scope, $http){
	$scope.admin="hello admin";

  var refresh = function () {
        $http.get('/movie/getMovie').success(function (response) {
            console.log('READ IS SUCCESSFUL');
			
            $scope.moviList = response;
            $scope.movi = "";
        });
		$http.get('/theatre/getTheatre').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.theatreList = response;
            $scope.theatre = "";
        });
		
		 $http.get('/city/getCity').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.cityList = response;
            $scope.city = "";
        });
		
		 $http.get('/showtiming/getShowtime').success(function (response) {
            console.log('READ IS SUCCESSFUL');
            $scope.showtimeList = response;
            $scope.showtimes = "";
        });
		
    };

    refresh();
	

    //movie
    $scope.addMovie = function (movi) {
          $http.get(`http://www.omdbapi.com/?t=${movi.moviTitle}&plot=short&r=json`).success(function (response) {
                            //console.log(response);
                            var movieObj={};
                            for(var key in response){
                                if(key=='Title' || key== 'Language' || key== 'Poster' || key== 'Genre' || key== 'Director' || key== 'Actors'){
                                    movieObj[key] = response[key];
                                     
                                }
                            }
                           
                           var serviceName = 'movi'  
                            $http.post('/movie/addMovie', movieObj).success(function (response) {
                                console.log(response);
                                console.log("CREATE IS SUCCESSFUL");
                                refresh();
                            });
                           
                        });
        console.log($scope.contact);
       
    };

    $scope.removeMovie = function (movie) {
      
	  var r = confirm("Are you sure you want to delete this movie?");
	  if (r == true) {
        $http.delete('/movie/deleteMovie/' + movie._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresh();
        });
	  }
    };

    $scope.editMovie = function (movie) {
         $http.get('/movie/getMovie/' + movie._id).success(function (response) {
            $scope.movi = response[0];
        });
    };

   

    $scope.updateMovie = function () {
        console.log("REACHED UPDATE");
        console.log($scope.movi._id);
        $http.put('/movie/updateMovie/' + $scope.movi._id, $scope.movi).success(function (response) {
            console.log(response);
            refresh();
        })
    };
	
	//theatre
	$scope.addTheatre = function (theatre) {
                         
                            $http.post('/theatre/addTheatre', theatre).success(function (response) {
								
                                console.log(response);
                                console.log("CREATE IS SUCCESSFUL");
                                refresh();
                            });
       
    };

    $scope.removeTheatre = function (theatre) {
       var r = confirm("Are you sure you want to delete this theater?");
	  if (r == true) {
        $http.delete('/theatre/deleteTheatre/' + theatre._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresh();
        });
	  }
    };

    $scope.editTheatre = function (theatre) {
         $http.get('/theatre/getTheatre/' + theatre._id).success(function (response) {
            $scope.theatre = response[0];
        });
    };

    $scope.updateTheatre = function () {
        console.log("REACHED UPDATE");
        $http.put('/theatre/updateTheatre/' + $scope.theatre._id, $scope.theatre).success(function (response) {
            console.log(response);
            refresh();
        })
    };
	
	//show timing
	 $scope.addShow = function (showtimes) {
		 
                            $http.post('/showtiming/addShow', showtimes).success(function (response) {
								
                                console.log(response);
                                console.log("CREATE IS SUCCESSFUL");
                                refresh();
                            });
       
    };

    $scope.removeShowtime = function (showtimes) {
       var r = confirm("Are you sure you want to delete this Show Time?");
	  if (r == true) {
        $http.delete('/showtiming/deleteShowtime/' + showtimes._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresh();
        });
	  }
    };

    $scope.editShowtime = function (showtimes) {
         $http.get('/showtiming/getShowtime/' + showtimes._id).success(function (response) {
            $scope.showtimes = response[0];
        });
    };

    $scope.updateShowtime = function () {
        console.log("REACHED UPDATE");

        $http.put('/showtiming/updateShowtime/' + $scope.showtimes._id, $scope.showtimes).success(function (response) {
            console.log(response);
            refresh();
        })
    };
	
	
	//city
	 $scope.addCity = function (city) {
                         
                            $http.post('/city/addCity', city).success(function (response) {
								
                                console.log(response);
                                console.log("CREATE IS SUCCESSFUL");
                                refresh();
                            });
       
    };

    $scope.removeCity = function (city) {
       var r = confirm("Are you sure you want to delete this City?");
	  if (r == true) {
        $http.delete('/city/deleteCity/' + city._id).success(function (response) {
            console.log(response);
            console.log('DELETED SUCCESSFULLY');
            refresh();
        });
	  }
    };

    $scope.editCity = function (city) {
         $http.get('/city/getCity/' + city._id).success(function (response) {
            $scope.city = response[0];
        });
    };

    $scope.updateCity = function () {
        console.log("REACHED UPDATE");
        
        $http.put('/city/updateCity/' + $scope.city._id, $scope.city).success(function (response) {
            console.log(response);
            refresh();
        })
    }
	
});