var logger = require('morgan');
var express = require('express');
var routes = require('./server/routes/movie-crud');
var theatres = require('./server/routes/theatre-crud');

var bodyParser=require('body-parser');

var app = express();
app.use(express.static(__dirname + '/client'));
app.use(bodyParser.json());

app.use('/movie', routes);
app.use('/theatre', theatres);


var mongo = require('mongodb');
var mongoose = require('mongoose');
var dbHost = 'mongodb://localhost:27017/test';
mongoose.connect(dbHost);

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
  console.log("Connected to DB");
});



var server = app.listen(4000, function () {
  console.log('listening on port 4000');
});








