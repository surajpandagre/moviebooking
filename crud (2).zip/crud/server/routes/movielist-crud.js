
var express = require('express');
var router = express.Router();
bodyParser = require('body-parser'), //parses information from POST


//Any requests to this controller must pass through this 'use' function
//Copy and pasted from method-override
router.use(bodyParser.urlencoded({ extended: true }))


var mongoose = require('mongoose');

var movieSchema = mongoose.Schema({
 
  moviTitle: String,
  moviLanguage: String,
  moviGenre: String,
  moviPoster: String,
  moviDirector: String,
  moviActors: String
 });
var Movies = mongoose.model('Movies', movieSchema, 'movie');

//Movie
router.get('/getMovielist', function (req, res) {
    console.log("REACHED GET FUNCTION ON SERVER");
    Movies.find({}, function (err, docs) {
         res.json(docs);
         
    }).sort({"_id":-1});
});

router.get('/getMovielist/:id', function (req, res) {
    console.log("REACHED GET ID FUNCTION ON SERVER");
     Movies.find({_id: req.params.id}, function (err, docs) {
         res.json(docs);
         
    });
});



// catch 404 and forward to error handler
router.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

module.exports = router;



