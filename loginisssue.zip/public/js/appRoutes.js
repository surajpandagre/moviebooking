
angular.module('appRoutes', ['ngRoute']).config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {

	$routeProvider.when('/', {
			templateUrl: 'views/home.html',
			controller: 'MainController'
		})

		.when('/booking', {
			templateUrl: 'views/booking.html',
			controller: 'BookingController'
		})

		.when('/movies', {
			templateUrl: 'views/movies.html',
			controller: 'MoviesController'	
		})

		.when('/confirm', {
			templateUrl: 'views/confirm.html',
			controller: 'ConfirmController'	
		})
		
		.when('/admin', {
			templateUrl: 'views/admin.html',
			controller: 'AdminController',
            access: { restricted: true }			
		})
		
		.when('/login', {
            templateUrl: 'views/login.html',
            controller: 'LoginController',
            access: { restricted: false }
        })
        .when('/logout', {
            controller: 'LogoutController',
            access: { restricted: true }
        })
        .when('/register', {
            templateUrl: 'views/register.html',
            controller: 'RegisterController',
            access: { restricted: false }
        })
		 .otherwise({
            redirectTo: '/'
        });
		

	$locationProvider.html5Mode(true);

}]);

angular.module('appRoutes', ['ngRoute']).config(['$routeProvider', '$locationProvider', function($rootScope, $location, $route, AuthService) {
    $rootScope.$on('$routeChangeStart',
        function(event, next, current) {
            AuthService.getUserStatus()
                .then(function() {
                    if (next.access.restricted && !AuthService.isLoggedIn()) {
                        $location.path('/login');
                        $route.reload();
                    }
                });
        });
}]);