angular.module('logoutController', []).controller('LogoutController', function($scope, $http, $rootScope, $location,$q, AuthService) {
	
	 $scope.logout = function () {

      // call logout from service
      AuthService.logout($q)
        .then(function () {
          $location.path('/login');
        });

    };
	
});
