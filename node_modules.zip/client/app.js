'use strict';

var app = angular.module('movieApp', [ 'ngRoute' ]);

app.config(function($routeProvider) {

  $routeProvider.when('/home', {
    templateUrl: 'views/home.html',
    controller: 'HomeController',
  })
  .when('/movie', {
    templateUrl: 'views/movie.html',
    controller: 'MovieController',
  })
  .when('/theatre', {
    templateUrl: 'views/theatre.html',
    controller: 'TheatreController',
  })
 
  .otherwise({
    redirectTo: '/home',
  });
});

