var api_key = 'key-b72b6ff5753e2d4d6641559029939e5e';
var domain = 'sandbox8c278c2574c4441e9d87c0af76040b0d.mailgun.org';
var mailgun = require('mailgun-js')({apiKey: api_key, domain: domain});
 
var data = {
  from: 'Bookmyshow <surajpandagre2012@gmail.com>',
  to: 'surajpandagre2012@gmail.com',
  subject: 'Bookmyshow ticket details',
  text: 'test'
};
 
mailgun.messages().send(data, function (error, body) {
  console.log(body);
});