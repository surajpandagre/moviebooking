
sampleApp.controller('ConfirmController', function($scope,$http, $rootScope, $location, AuthService) {

//$scope.selectedSeats=['A1','B1','A2'];
var refresh=function(){
	
	    
$http.get('/booking/getBooking').success(function (response) {
			
            var stimes1='';
			var stimes11='';
			var c='';
			
			for(let resp of response)
			{
				
				if(resp.bookingdate==$rootScope.sdate && resp.bookingtime==$rootScope.showtime && resp.bookedMovie==$rootScope.bookedMovie && resp.city==$rootScope.city && resp.theatre==$rootScope.title )
				{
			
				
				stimes1+=resp.seat_no;
				c=stimes11.concat(stimes1);
				
			
			}}
			$scope.selectedSeats = c;
            console.log($scope.selectedSeats);
            
        });
};
refresh();

var s_seat;
$(document).ready(function(){
  var countdiv=[];
  $('.floating-box').click(function(){
          var id=$(this).attr('id');
          countdiv.push(id);
          $rootScope.TotalSeat=JSON.stringify(countdiv);

          s_seat= document.getElementById("st").innerHTML=countdiv;
	
          console.log(s_seat);
          console.log(countdiv.length);
		  $rootScope.TotalSeatLength=countdiv.length;
		  
		  var total=$rootScope.TotalSeatLength*$rootScope.totalPrice;
		  console.log(total);
         document.getElementById("totprice").innerHTML=total;
		 $(this).addClass('selecteds');
		  
  });
  });


$scope.totalSeats=$rootScope.totalSeats; 
$scope.totalPrice=$rootScope.totalPrice; 
$scope.showtime=$rootScope.showtime; 
$scope.fromdate=$rootScope.fromdate; 
$scope.todate=$rootScope.todate;
$scope.title=$rootScope.title;
$scope.bookedMovie=$rootScope.bookedMovie;
$scope.moviPoster=$rootScope.moviPoster;
$scope.city=$rootScope.city; 
$scope.confirm="Confirm your Tickets of "+$scope.bookedMovie+" movie at "+$scope.title;

$scope.shows = true;
$scope.details = false;  





    
	
	
	
	
	$scope.bookTicket = function () {
		 $scope.shows = false;
	     $scope.details = true;
		 
		
		 
		 if($rootScope.sdate==undefined)
		 {
		
			 $scope.sdt=$scope.fromdate;
		 }
		 else{
			 $scope.sdt=$rootScope.sdate;
		 }
		 
		  
		 
		  var cdt = moment().format("MM/DD/YYYY, h:mm:ss a");

          $scope.cdt=cdt;
		 
		 var bookingid=Math.floor((Math.random() * 1000000) + 1);
		 $scope.bookingid=bookingid;
		 $rootScope.email=$scope.email;
		 
		 AuthService.register($scope.email, '12345');
		 
		 $scope.seat_no=$rootScope.TotalSeat;
		 $scope.length=$rootScope.TotalSeatLength;
		 
		 var pass=12345;
         $scope.msg=$scope.name+" your Ticket has been booked Successfully on "+$scope.sdt+" at "+$scope.showtime+". Your Booking Id is: "+$scope.email+" Your password is: "+pass;
		 
		 
		  
		var bookingObj={};
		bookingObj['showtime']=$scope.showtime;
		bookingObj['bookingid']=$scope.bookingid;
		bookingObj['totalSeats']=$scope.totalSeats;
		bookingObj['totalPrice']=$rootScope.totalPrice;
		bookingObj['quantity']=$scope.length;
		bookingObj['cdt']=$scope.cdt;
		bookingObj['sdt']=$scope.sdt;
		bookingObj['name']=$scope.name;
		bookingObj['email']=$scope.email;
		bookingObj['title']=$scope.title;
		bookingObj['city']=$scope.city;
		bookingObj['bookedMovie']=$scope.bookedMovie;
		bookingObj['moviPoster']=$scope.moviPoster;
		bookingObj['seat_no'] =$scope.seat_no;
		bookingObj['asmid']=$rootScope.asmid;
		
		
		$http.post('/booking/addBooking/', bookingObj).success(function (response) {
								$scope.shows = false;
                                $scope.details = true;
                                console.log(response);
                                console.log("Booking created SUCCESSFUL");
								//$location.path('/cancellation');

                            });
							
							
	 
    };
	
	$scope.gotoCancel = function () {
      $rootScope.email=$rootScope.email;
	  $location.path('/cancellation');
    };

});